package com.partagewifi.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    public static final String PREFS = "config";
    public static final String KEY_NAME = "name";
    public static final String KEY_PASS = "pass";
    private static final int REQ_PERMS = 1;

    private static final String HELP =
            "COMMENT ÇA MARCHE\n\n"
            + "Sur CE téléphone :\n"
            + "1. Connecte-toi au Wi-Fi (et à sa page de connexion s'il y en a une).\n"
            + "2. Appuie sur « Démarrer le partage ».\n\n"
            + "Sur CHAQUE autre téléphone (Android) :\n"
            + "1. Paramètres > Wi-Fi > choisis le réseau affiché ci-dessus et entre le mot de passe.\n"
            + "2. Appui long sur ce réseau (ou l'engrenage) > Modifier / Avancé > Proxy : Manuel.\n"
            + "3. Nom d'hôte : 192.168.49.1 — Port : 8282 — Enregistrer.\n"
            + "4. Si « Pas d'accès Internet » s'affiche, choisis « Rester connecté » "
            + "et coupe les données mobiles de ce téléphone.\n\n"
            + "iPhone : Réglages > Wi-Fi > (i) > Configurer le proxy > Manuel > "
            + "Serveur 192.168.49.1, Port 8282.\n\n"
            + "Navigateur, YouTube, WhatsApp et la plupart des applis passent par le proxy. "
            + "Quelques applis (certains jeux) l'ignorent et n'auront pas Internet.";

    private SharedPreferences prefs;
    private TextView statusView;
    private TextView infoView;
    private TextView statsView;
    private EditText nameEdit;
    private EditText passEdit;
    private Button toggleButton;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresher = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.contains(KEY_PASS)) {
            prefs.edit().putString(KEY_NAME, "PartageWifi").putString(KEY_PASS, randomPassword()).apply();
        }

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(20);
        root.setPadding(p, p, p, p);
        scroll.addView(root);

        root.addView(text("Partage Wi-Fi", 26, true, Color.parseColor("#1565C0")));
        root.addView(text("Partage le Wi-Fi auquel ce téléphone est connecté avec d'autres téléphones.",
                14, false, Color.DKGRAY));

        statusView = text("", 16, true, Color.BLACK);
        addSpaced(root, statusView, 16);

        addSpaced(root, text("Nom du réseau (lettres, chiffres, - ou _)", 13, false, Color.DKGRAY), 16);
        nameEdit = new EditText(this);
        nameEdit.setSingleLine(true);
        nameEdit.setText(prefs.getString(KEY_NAME, "PartageWifi"));
        root.addView(nameEdit);

        addSpaced(root, text("Mot de passe (8 caractères minimum)", 13, false, Color.DKGRAY), 8);
        passEdit = new EditText(this);
        passEdit.setSingleLine(true);
        passEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        passEdit.setText(prefs.getString(KEY_PASS, ""));
        root.addView(passEdit);

        toggleButton = new Button(this);
        toggleButton.setOnClickListener(v -> onToggle());
        addSpaced(root, toggleButton, 16);

        infoView = text("", 16, false, Color.BLACK);
        infoView.setTextIsSelectable(true);
        addSpaced(root, infoView, 16);

        statsView = text("", 14, false, Color.DKGRAY);
        addSpaced(root, statsView, 12);

        if (Build.VERSION.SDK_INT >= 23) {
            Button battery = new Button(this);
            battery.setText("Empêcher Android de couper l'appli (batterie)");
            battery.setOnClickListener(v -> openBatterySettings());
            addSpaced(root, battery, 16);
        }

        addSpaced(root, text(HELP, 14, false, Color.DKGRAY), 20);

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresher);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(refresher);
        super.onPause();
    }

    private void onToggle() {
        if (ShareService.running) {
            startService(new Intent(this, ShareService.class).setAction(ShareService.ACTION_STOP));
            return;
        }
        String name = nameEdit.getText().toString().trim();
        String pass = passEdit.getText().toString();
        if (!name.matches("[A-Za-z0-9_-]{1,20}")) {
            toast("Nom invalide : 1 à 20 lettres ou chiffres, sans espace ni accent.");
            return;
        }
        if (!pass.matches("[\\x20-\\x7E]{8,63}")) {
            toast("Mot de passe invalide : 8 à 63 caractères, sans accent.");
            return;
        }
        prefs.edit().putString(KEY_NAME, name).putString(KEY_PASS, pass).apply();
        checkPermissionsAndStart();
    }

    private String wifiPermission() {
        return Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.NEARBY_WIFI_DEVICES
                : Manifest.permission.ACCESS_FINE_LOCATION;
    }

    private void checkPermissionsAndStart() {
        if (Build.VERSION.SDK_INT < 23) {
            startShare();
            return;
        }
        List<String> missing = new ArrayList<>();
        if (checkSelfPermission(wifiPermission()) != PackageManager.PERMISSION_GRANTED) {
            missing.add(wifiPermission());
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (missing.isEmpty()) {
            startShare();
        } else {
            requestPermissions(missing.toArray(new String[0]), REQ_PERMS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMS) return;
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(wifiPermission()) == PackageManager.PERMISSION_GRANTED) {
            startShare();
        } else {
            String what = Build.VERSION.SDK_INT >= 33 ? "« Appareils à proximité »" : "« Position »";
            toast("L'appli a besoin de la permission " + what + " pour créer le réseau Wi-Fi.");
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    android.net.Uri.fromParts("package", getPackageName(), null));
            try {
                startActivity(i);
            } catch (RuntimeException ignored) {
            }
        }
    }

    private void startShare() {
        Intent i = new Intent(this, ShareService.class).setAction(ShareService.ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(i);
            } else {
                startService(i);
            }
        } catch (RuntimeException e) {
            toast("Impossible de démarrer : " + e.getMessage());
        }
        refresh();
    }

    private void openBatterySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            toast("Choisis « Toutes les applis », puis « Partage Wi-Fi » > Ne pas optimiser.");
        } catch (RuntimeException e) {
            toast("Ouvre Paramètres > Batterie et retire les restrictions pour « Partage Wi-Fi ».");
        }
    }

    private void refresh() {
        boolean running = ShareService.running;
        toggleButton.setText(running ? "ARRÊTER LE PARTAGE" : "DÉMARRER LE PARTAGE");
        nameEdit.setEnabled(!running);
        passEdit.setEnabled(!running);
        statusView.setText("État : " + ShareService.state);

        if (running && ShareService.groupReady) {
            infoView.setText("Sur les autres téléphones, connecte-toi à :\n\n"
                    + "Réseau : " + ShareService.networkName + "\n"
                    + "Mot de passe : " + ShareService.passphrase + "\n\n"
                    + "Puis règle le proxy de ce réseau :\n"
                    + "Nom d'hôte : " + ShareService.GROUP_OWNER_IP + "\n"
                    + "Port : " + ShareService.PROXY_PORT + "\n\n"
                    + "(ou proxy Automatique / PAC : http://" + ShareService.GROUP_OWNER_IP + ":"
                    + ShareService.PROXY_PORT + "/proxy.pac)");
            ProxyServer px = ShareService.proxy;
            statsView.setText("Wi-Fi source : "
                    + (ShareService.upstreamOk ? "connecté ✓" : "NON connecté ✗ — connecte ce téléphone au Wi-Fi")
                    + "\nAppareils connectés : " + ShareService.clients
                    + "\nConnexions en cours : " + (px != null ? px.getActive() : 0));
            infoView.setVisibility(View.VISIBLE);
            statsView.setVisibility(View.VISIBLE);
        } else {
            infoView.setVisibility(View.GONE);
            statsView.setVisibility(View.GONE);
        }
    }

    // ------------------------------------------------------------- Outils UI

    private TextView text(String s, int sizeSp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void addSpaced(LinearLayout root, View v, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topDp);
        root.addView(v, lp);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private static String randomPassword() {
        String alphabet = "abcdefghjkmnpqrstuvwxyz23456789";
        SecureRandom r = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) sb.append(alphabet.charAt(r.nextInt(alphabet.length())));
        return sb.toString();
    }
}
