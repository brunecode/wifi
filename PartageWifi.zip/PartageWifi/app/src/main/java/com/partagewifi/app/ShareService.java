package com.partagewifi.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiManager;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pGroup;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Service qui :
 *  1. crée un réseau Wi-Fi Direct (les autres téléphones s'y connectent comme à un Wi-Fi normal),
 *  2. lance le proxy qui fait sortir leur trafic par le Wi-Fi de ce téléphone,
 *  3. reste actif en arrière-plan (notification permanente).
 */
public class ShareService extends Service {

    public static final String ACTION_START = "com.partagewifi.app.START";
    public static final String ACTION_STOP = "com.partagewifi.app.STOP";
    public static final int PROXY_PORT = 8282;
    public static final String GROUP_OWNER_IP = "192.168.49.1";

    private static final String CHANNEL_ID = "partage";
    private static final int NOTIF_ID = 1;
    private static final int MAX_ATTEMPTS = 6;

    // État partagé avec l'écran principal.
    public static volatile boolean running;
    public static volatile boolean groupReady;
    public static volatile boolean upstreamOk;
    public static volatile String state = "Arrêté";
    public static volatile String networkName = "";
    public static volatile String passphrase = "";
    public static volatile int clients;
    public static volatile ProxyServer proxy;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WifiP2pManager p2p;
    private WifiP2pManager.Channel channel;
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback netCallback;
    private volatile Network currentUpstream;
    private BroadcastReceiver p2pReceiver;
    private String wantedName;
    private String wantedPass;
    private int attempts;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        if (ACTION_STOP.equals(action)) {
            stopEverything("Arrêté");
            stopForegroundCompat();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_STICKY;

        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        wantedName = prefs.getString(MainActivity.KEY_NAME, "PartageWifi");
        wantedPass = prefs.getString(MainActivity.KEY_PASS, "partage123");

        createChannel();
        try {
            startForegroundCompat(buildNotification("Démarrage…"));
        } catch (RuntimeException e) {
            state = "Impossible de démarrer le service : " + e.getMessage();
            stopSelf();
            return START_NOT_STICKY;
        }

        running = true;
        groupReady = false;
        attempts = 0;
        setState("Démarrage…");
        acquireLocks();
        if (!startProxy()) return START_NOT_STICKY;
        watchUpstream();
        registerP2pReceiver();
        setupP2p();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (running) stopEverything("Arrêté");
        super.onDestroy();
    }

    // ---------------------------------------------------------------- Proxy

    private boolean startProxy() {
        ProxyServer px = new ProxyServer(PROXY_PORT, GROUP_OWNER_IP);
        try {
            px.start();
        } catch (Exception e) {
            fail("Impossible d'ouvrir le port " + PROXY_PORT + " : " + e.getMessage());
            return false;
        }
        proxy = px;
        return true;
    }

    /** Suit le réseau Wi-Fi « source » pour y faire sortir le trafic. */
    private void watchUpstream() {
        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (cm == null) return;
        NetworkRequest req = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build();
        netCallback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(Network network) {
                currentUpstream = network;
                ProxyServer px = proxy;
                if (px != null) px.setUpstream(network);
                upstreamOk = true;
            }

            @Override
            public void onLost(Network network) {
                if (network.equals(currentUpstream)) {
                    currentUpstream = null;
                    ProxyServer px = proxy;
                    if (px != null) px.setUpstream(null);
                    upstreamOk = false;
                }
            }
        };
        try {
            cm.registerNetworkCallback(req, netCallback);
        } catch (RuntimeException e) {
            netCallback = null;
        }
    }

    // ---------------------------------------------------------- Wi-Fi Direct

    private void setupP2p() {
        p2p = (WifiP2pManager) getSystemService(WIFI_P2P_SERVICE);
        if (p2p == null) {
            fail("Ce téléphone ne prend pas en charge le Wi-Fi Direct.");
            return;
        }
        channel = p2p.initialize(this, getMainLooper(), () -> {
            if (!running) return;
            groupReady = false;
            setState("Wi-Fi Direct interrompu, nouvelle tentative…");
            handler.postDelayed(this::setupP2p, 3000);
        });
        removeThenCreate();
    }

    private void removeThenCreate() {
        if (!running) return;
        setState("Création du réseau Wi-Fi Direct…");
        try {
            p2p.removeGroup(channel, new WifiP2pManager.ActionListener() {
                @Override
                public void onSuccess() {
                    handler.postDelayed(ShareService.this::createGroup, 1000);
                }

                @Override
                public void onFailure(int reason) {
                    // Pas de groupe existant : normal.
                    handler.postDelayed(ShareService.this::createGroup, 300);
                }
            });
        } catch (SecurityException e) {
            fail("Permission refusée. Autorise « Appareils à proximité » / « Position » pour l'appli.");
        }
    }

    private void createGroup() {
        if (!running) return;
        attempts++;
        // Les 3 premiers essais avec ton nom et ton mot de passe, puis les réglages automatiques.
        final boolean custom = Build.VERSION.SDK_INT >= 29 && attempts <= 3;

        WifiP2pManager.ActionListener listener = new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                setState("Réseau créé, récupération des informations…");
                handler.postDelayed(() -> fetchGroupInfo(0), 800);
            }

            @Override
            public void onFailure(int reason) {
                if (!running) return;
                if (reason == WifiP2pManager.P2P_UNSUPPORTED) {
                    fail("Le Wi-Fi Direct n'est pas pris en charge par ce téléphone.");
                    return;
                }
                if (attempts < MAX_ATTEMPTS) {
                    setState("Échec (" + reasonText(reason) + "), nouvelle tentative…");
                    handler.postDelayed(ShareService.this::removeThenCreate, 2000);
                } else {
                    fail("Impossible de créer le réseau (" + reasonText(reason) + ").\n"
                            + "Vérifie que le Wi-Fi ET la localisation sont activés, "
                            + "désactive le point d'accès mobile s'il est allumé, puis réessaie.");
                }
            }
        };

        try {
            if (custom) {
                WifiP2pConfig cfg = new WifiP2pConfig.Builder()
                        .setNetworkName("DIRECT-PW-" + wantedName)
                        .setPassphrase(wantedPass)
                        .setGroupOperatingBand(WifiP2pConfig.GROUP_OWNER_BAND_2GHZ)
                        .build();
                p2p.createGroup(channel, cfg, listener);
            } else {
                p2p.createGroup(channel, listener);
            }
        } catch (SecurityException e) {
            fail("Permission refusée. Autorise « Appareils à proximité » / « Position » pour l'appli.");
        } catch (IllegalArgumentException e) {
            attempts = 3; // nom/mot de passe refusés : on passe aux réglages automatiques
            handler.postDelayed(this::createGroup, 500);
        }
    }

    private void fetchGroupInfo(final int tries) {
        if (!running || p2p == null) return;
        try {
            p2p.requestGroupInfo(channel, group -> {
                if (!running) return;
                if (group == null || group.getNetworkName() == null) {
                    if (tries < 10) {
                        handler.postDelayed(() -> fetchGroupInfo(tries + 1), 1000);
                    } else if (attempts < MAX_ATTEMPTS) {
                        removeThenCreate();
                    } else {
                        fail("Le réseau Wi-Fi Direct n'a pas démarré. Redémarre le Wi-Fi et réessaie.");
                    }
                    return;
                }
                applyGroup(group);
            });
        } catch (SecurityException e) {
            fail("Permission refusée. Autorise « Appareils à proximité » / « Position » pour l'appli.");
        }
    }

    private void applyGroup(WifiP2pGroup group) {
        networkName = group.getNetworkName();
        passphrase = group.getPassphrase() != null ? group.getPassphrase() : "";
        clients = group.getClientList() != null ? group.getClientList().size() : 0;
        boolean wasReady = groupReady;
        groupReady = true;
        if (!wasReady) attempts = 0;
        setState("Partage actif");
    }

    private void registerP2pReceiver() {
        p2pReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!running || !groupReady || p2p == null) return;
                try {
                    p2p.requestGroupInfo(channel, group -> {
                        if (!running) return;
                        if (group == null) {
                            // Le réseau a disparu (le système l'a coupé) : on le recrée.
                            groupReady = false;
                            clients = 0;
                            handler.postDelayed(ShareService.this::removeThenCreate, 2000);
                        } else {
                            applyGroup(group);
                        }
                    });
                } catch (SecurityException ignored) {
                }
            }
        };
        IntentFilter filter = new IntentFilter(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(p2pReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(p2pReceiver, filter);
        }
    }

    private static String reasonText(int reason) {
        switch (reason) {
            case WifiP2pManager.BUSY:
                return "Wi-Fi occupé";
            case WifiP2pManager.P2P_UNSUPPORTED:
                return "non pris en charge";
            case WifiP2pManager.ERROR:
            default:
                return "erreur interne";
        }
    }

    // ----------------------------------------------------------- Ressources

    @SuppressWarnings("deprecation")
    private void acquireLocks() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PartageWifi:partage");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire();
        } catch (RuntimeException ignored) {
        }
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "PartageWifi:wifi");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
        } catch (RuntimeException ignored) {
        }
    }

    private void stopEverything(String finalState) {
        handler.removeCallbacksAndMessages(null);
        running = false;
        groupReady = false;
        upstreamOk = false;
        clients = 0;

        if (p2pReceiver != null) {
            try {
                unregisterReceiver(p2pReceiver);
            } catch (RuntimeException ignored) {
            }
            p2pReceiver = null;
        }
        if (p2p != null && channel != null) {
            try {
                p2p.removeGroup(channel, null);
            } catch (RuntimeException ignored) {
            }
        }
        p2p = null;
        channel = null;

        if (cm != null && netCallback != null) {
            try {
                cm.unregisterNetworkCallback(netCallback);
            } catch (RuntimeException ignored) {
            }
        }
        netCallback = null;
        currentUpstream = null;

        ProxyServer px = proxy;
        proxy = null;
        if (px != null) px.stop();

        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        wakeLock = null;
        wifiLock = null;

        state = finalState;
    }

    private void fail(String message) {
        stopEverything(message);
        stopForegroundCompat();
        stopSelf();
    }

    private void setState(String s) {
        state = s;
        if (running) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) {
                String text = groupReady ? "Réseau : " + networkName + " — " + s : s;
                nm.notify(NOTIF_ID, buildNotification(text));
            }
        }
    }

    // --------------------------------------------------------- Notification

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Partage Wi-Fi", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    @SuppressWarnings("deprecation")
    private Notification buildNotification(String text) {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent open = PendingIntent.getActivity(
                this, 0, new Intent(this, MainActivity.class), flags);
        PendingIntent stop = PendingIntent.getService(
                this, 1, new Intent(this, ShareService.class).setAction(ACTION_STOP), flags);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Partage Wi-Fi")
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(open)
                .addAction(0, "Arrêter", stop);
        return b.build();
    }

    private void startForegroundCompat(Notification n) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    @SuppressWarnings("deprecation")
    private void stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= 24) {
            stopForeground(STOP_FOREGROUND_REMOVE);
        } else {
            stopForeground(true);
        }
    }
}
