package com.partagewifi.app;

import android.net.Network;
import android.os.Build;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Petit proxy HTTP/HTTPS.
 * Les appareils connectés au réseau Wi-Fi Direct l'utilisent pour sortir sur Internet
 * à travers le Wi-Fi auquel ce téléphone est connecté.
 */
public class ProxyServer {

    private static final Charset ISO = Charset.forName("ISO-8859-1");
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final int MAX_HEADER = 64 * 1024;
    private static final int CONNECT_TIMEOUT_MS = 15000;
    private static final int HEADER_TIMEOUT_MS = 30000;
    private static final int DRAIN_TIMEOUT_MS = 15000;
    private static final int BUFFER_SIZE = 16 * 1024;

    private final int port;
    private final String localIp;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final AtomicInteger active = new AtomicInteger();
    private final Set<Socket> sockets =
            Collections.newSetFromMap(new ConcurrentHashMap<Socket, Boolean>());

    private volatile ServerSocket server;
    private volatile boolean running;
    private volatile Network upstream;

    public ProxyServer(int port, String localIp) {
        this.port = port;
        this.localIp = localIp;
    }

    /** Réseau Wi-Fi par lequel les connexions sortent (null = réseau par défaut). */
    public void setUpstream(Network network) {
        upstream = network;
    }

    public int getActive() {
        return active.get();
    }

    public void start() throws IOException {
        ServerSocket ss = new ServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new InetSocketAddress(port), 128);
        server = ss;
        running = true;
        Thread t = new Thread(this::acceptLoop, "proxy-accept");
        t.setDaemon(true);
        t.start();
    }

    public void stop() {
        running = false;
        closeQuietly(server);
        List<Socket> copy = new ArrayList<>(sockets);
        for (Socket s : copy) closeQuietly(s);
        sockets.clear();
        pool.shutdownNow();
    }

    private void acceptLoop() {
        while (running) {
            Socket client;
            try {
                client = server.accept();
            } catch (IOException e) {
                if (!running) break;
                sleepQuietly(200);
                continue;
            }
            if (!isAllowedClient(client.getInetAddress())) {
                // Le proxy ne sert que les appareils du réseau Wi-Fi Direct (192.168.49.x).
                closeQuietly(client);
                continue;
            }
            sockets.add(client);
            try {
                pool.execute(() -> handle(client));
            } catch (Exception e) {
                sockets.remove(client);
                closeQuietly(client);
            }
        }
    }

    private static boolean isAllowedClient(InetAddress a) {
        if (a == null) return false;
        if (a.isLoopbackAddress()) return true;
        byte[] b = a.getAddress();
        return b.length == 4 && (b[0] & 0xff) == 192 && (b[1] & 0xff) == 168 && (b[2] & 0xff) == 49;
    }

    private void handle(Socket client) {
        active.incrementAndGet();
        Socket remote = null;
        try {
            client.setSoTimeout(HEADER_TIMEOUT_MS);
            client.setTcpNoDelay(true);
            InputStream cin = new java.io.BufferedInputStream(client.getInputStream(), BUFFER_SIZE);
            OutputStream cout = client.getOutputStream();

            byte[] head = readHead(cin);
            if (head == null) return;
            String headStr = new String(head, ISO);
            int eol = headStr.indexOf("\r\n");
            if (eol <= 0) {
                sendError(cout, 400, "Requête invalide");
                return;
            }
            String[] parts = headStr.substring(0, eol).split(" ");
            if (parts.length < 3) {
                sendError(cout, 400, "Requête invalide");
                return;
            }
            String method = parts[0];
            String target = parts[1];
            String version = parts[2];

            if (method.equalsIgnoreCase("CONNECT")) {
                // HTTPS : on ouvre un tunnel vers le site.
                HostPort hp = HostPort.parse(target, 443);
                if (isSelf(hp)) {
                    sendError(cout, 403, "Destination interdite");
                    return;
                }
                try {
                    remote = openUpstream(hp.host, hp.port);
                } catch (IOException e) {
                    sendError(cout, 502, "Impossible de joindre " + hp.host);
                    return;
                }
                cout.write("HTTP/1.1 200 Connection Established\r\n\r\n".getBytes(ISO));
                cout.flush();
                client.setSoTimeout(0);
                relay(client, cin, remote);

            } else if (target.regionMatches(true, 0, "http://", 0, 7)) {
                // HTTP simple : on réécrit la requête et on la transmet.
                String rest = target.substring(7);
                int slash = rest.indexOf('/');
                String authority = slash < 0 ? rest : rest.substring(0, slash);
                String path = slash < 0 ? "/" : rest.substring(slash);
                HostPort hp = HostPort.parse(authority, 80);
                if (isSelf(hp)) {
                    serveLocal(cout, method, path);
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.append(method).append(' ').append(path).append(' ').append(version).append("\r\n");
                boolean hostSeen = false;
                boolean upgrade = false;
                for (String line : headStr.substring(eol + 2).split("\r\n")) {
                    if (line.isEmpty()) continue;
                    String lower = line.toLowerCase(Locale.ROOT);
                    if (lower.startsWith("proxy-connection:")
                            || lower.startsWith("proxy-authorization:")
                            || lower.startsWith("keep-alive:")) {
                        continue;
                    }
                    if (lower.startsWith("connection:")) {
                        if (lower.contains("upgrade")) {
                            upgrade = true;
                            sb.append(line).append("\r\n");
                        }
                        continue;
                    }
                    if (lower.startsWith("host:")) hostSeen = true;
                    sb.append(line).append("\r\n");
                }
                if (!hostSeen) sb.append("Host: ").append(authority).append("\r\n");
                if (!upgrade) sb.append("Connection: close\r\n");
                sb.append("\r\n");

                try {
                    remote = openUpstream(hp.host, hp.port);
                } catch (IOException e) {
                    sendError(cout, 502, "Impossible de joindre " + hp.host);
                    return;
                }
                OutputStream rout = remote.getOutputStream();
                rout.write(sb.toString().getBytes(ISO));
                rout.flush();
                client.setSoTimeout(0);
                relay(client, cin, remote);

            } else {
                // Requête directe vers 192.168.49.1:8282 (page d'aide ou fichier PAC).
                serveLocal(cout, method, target);
            }
        } catch (Exception ignored) {
            // Connexion terminée ou erreur réseau : rien à faire.
        } finally {
            closeQuietly(remote);
            closeQuietly(client);
            if (remote != null) sockets.remove(remote);
            sockets.remove(client);
            active.decrementAndGet();
        }
    }

    private boolean isSelf(HostPort hp) {
        String h = hp.host.toLowerCase(Locale.ROOT);
        // Ce téléphone lui-même : on ne laisse pas les appareils connectés y accéder via le proxy.
        return h.equals("localhost") || h.startsWith("127.") || h.equals(localIp) || h.equals("::1");
    }

    private Socket openUpstream(String host, int port) throws IOException {
        Network net = upstream;
        boolean bind = net != null && Build.VERSION.SDK_INT >= 23;
        InetAddress[] addrs;
        if (bind) {
            try {
                addrs = net.getAllByName(host);
            } catch (IOException e) {
                bind = false;
                addrs = InetAddress.getAllByName(host);
            }
        } else {
            addrs = InetAddress.getAllByName(host);
        }
        if (addrs == null || addrs.length == 0) throw new UnknownHostException(host);

        // On essaie d'abord les adresses IPv4 (plus fiables sur beaucoup de réseaux Wi-Fi).
        List<InetAddress> ordered = new ArrayList<>();
        for (InetAddress a : addrs) if (a.getAddress().length == 4) ordered.add(a);
        for (InetAddress a : addrs) if (a.getAddress().length != 4) ordered.add(a);

        IOException last = null;
        for (InetAddress a : ordered) {
            Socket s = new Socket();
            try {
                if (bind) {
                    try {
                        net.bindSocket(s);
                    } catch (IOException e) {
                        // Le réseau Wi-Fi a disparu : on tente via le réseau par défaut.
                        closeQuietly(s);
                        s = new Socket();
                    }
                }
                s.connect(new InetSocketAddress(a, port), CONNECT_TIMEOUT_MS);
                s.setTcpNoDelay(true);
                s.setKeepAlive(true);
                sockets.add(s);
                return s;
            } catch (IOException e) {
                last = e;
                closeQuietly(s);
            }
        }
        throw last != null ? last : new UnknownHostException(host);
    }

    private void relay(Socket client, InputStream cin, Socket remote) throws IOException {
        final InputStream rin = remote.getInputStream();
        final OutputStream rout = remote.getOutputStream();
        final OutputStream cout = client.getOutputStream();

        Future<?> upload = pool.submit(() -> {
            pipe(cin, rout);
            shutdownOutput(remote);
        });

        pipe(rin, cout);
        shutdownOutput(client);
        // Le site a fini d'envoyer : on laisse un peu de temps à l'autre sens puis on ferme.
        try {
            client.setSoTimeout(DRAIN_TIMEOUT_MS);
        } catch (IOException ignored) {
        }
        try {
            upload.get();
        } catch (Exception ignored) {
        }
    }

    private static void pipe(InputStream in, OutputStream out) {
        byte[] buf = new byte[BUFFER_SIZE];
        try {
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                out.flush();
            }
        } catch (IOException ignored) {
        }
    }

    private static byte[] readHead(InputStream in) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream(1024);
        int state = 0; // progression dans "\r\n\r\n"
        while (true) {
            int b = in.read();
            if (b == -1) return null;
            buf.write(b);
            if (b == '\r') {
                state = (state == 2) ? 3 : 1;
            } else if (b == '\n') {
                if (state == 1) {
                    state = 2;
                } else if (state == 3) {
                    return buf.toByteArray();
                } else {
                    state = 0;
                }
            } else {
                state = 0;
            }
            if (buf.size() > MAX_HEADER) throw new IOException("En-tête trop grand");
        }
    }

    private void serveLocal(OutputStream out, String method, String target) throws IOException {
        String path = target;
        int q = path.indexOf('?');
        if (q >= 0) path = path.substring(0, q);
        String body;
        String type;
        if (path.equals("/proxy.pac") || path.equals("/wpad.dat")) {
            type = "application/x-ns-proxy-autoconfig";
            body = pacFile();
        } else {
            type = "text/html; charset=utf-8";
            body = helpPage();
        }
        byte[] bytes = body.getBytes(UTF8);
        String headers = "HTTP/1.1 200 OK\r\n"
                + "Content-Type: " + type + "\r\n"
                + "Content-Length: " + bytes.length + "\r\n"
                + "Cache-Control: no-store\r\n"
                + "Connection: close\r\n\r\n";
        out.write(headers.getBytes(ISO));
        if (!method.equalsIgnoreCase("HEAD")) out.write(bytes);
        out.flush();
    }

    private String pacFile() {
        return "function FindProxyForURL(url, host) {\n"
                + "  if (isPlainHostName(host) || host == \"" + localIp + "\") return \"DIRECT\";\n"
                + "  return \"PROXY " + localIp + ":" + port + "\";\n"
                + "}\n";
    }

    private String helpPage() {
        return "<!doctype html><html lang=\"fr\"><head><meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<title>Partage Wi-Fi</title>"
                + "<style>body{font-family:sans-serif;max-width:560px;margin:24px auto;padding:0 16px;line-height:1.5}"
                + "code{background:#eee;padding:2px 6px;border-radius:4px}</style></head><body>"
                + "<h1>Partage Wi-Fi</h1>"
                + "<p>Tu es bien connecté au téléphone qui partage le Wi-Fi.</p>"
                + "<p>Pour avoir Internet, règle le <b>proxy</b> de ce réseau Wi-Fi :</p>"
                + "<ul><li>Proxy : <b>Manuel</b></li>"
                + "<li>Nom d'hôte : <code>" + localIp + "</code></li>"
                + "<li>Port : <code>" + port + "</code></li></ul>"
                + "<p>Ou bien : proxy <b>Automatique / PAC</b> avec l'adresse "
                + "<code>http://" + localIp + ":" + port + "/proxy.pac</code></p>"
                + "</body></html>";
    }

    private static void sendError(OutputStream out, int code, String message) {
        try {
            String reason = code == 403 ? "Forbidden" : code == 400 ? "Bad Request" : "Bad Gateway";
            byte[] body = ("<html><body><h3>Partage Wi-Fi</h3><p>" + message + "</p></body></html>").getBytes(UTF8);
            String h = "HTTP/1.1 " + code + " " + reason + "\r\n"
                    + "Content-Type: text/html; charset=utf-8\r\n"
                    + "Content-Length: " + body.length + "\r\n"
                    + "Connection: close\r\n\r\n";
            out.write(h.getBytes(ISO));
            out.write(body);
            out.flush();
        } catch (IOException ignored) {
        }
    }

    private static void shutdownOutput(Socket s) {
        try {
            if (!s.isClosed() && !s.isOutputShutdown()) s.shutdownOutput();
        } catch (IOException ignored) {
        }
    }

    private static void closeQuietly(Closeable c) {
        if (c == null) return;
        try {
            c.close();
        } catch (IOException ignored) {
        }
    }

    private static void sleepQuietly(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }

    /** Hôte + port extraits de "site.com", "site.com:8080" ou "[::1]:443". */
    static final class HostPort {
        final String host;
        final int port;

        HostPort(String host, int port) {
            this.host = host;
            this.port = port;
        }

        static HostPort parse(String s, int defaultPort) {
            int at = s.lastIndexOf('@');
            if (at >= 0) s = s.substring(at + 1);
            if (s.startsWith("[")) {
                int end = s.indexOf(']');
                if (end < 0) return new HostPort(s, defaultPort);
                String host = s.substring(1, end);
                int p = defaultPort;
                if (end + 1 < s.length() && s.charAt(end + 1) == ':') {
                    p = Integer.parseInt(s.substring(end + 2));
                }
                return new HostPort(host, p);
            }
            int c = s.lastIndexOf(':');
            if (c > 0 && s.indexOf(':') == c) {
                return new HostPort(s.substring(0, c), Integer.parseInt(s.substring(c + 1)));
            }
            return new HostPort(s, defaultPort);
        }
    }
}
