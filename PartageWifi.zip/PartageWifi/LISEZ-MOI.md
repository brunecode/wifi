# Partage Wi-Fi

Appli Android qui partage le Wi-Fi auquel ton téléphone est connecté avec d'autres téléphones.

Comment ça marche : l'appli crée un réseau **Wi-Fi Direct** (les autres téléphones s'y connectent comme à un Wi-Fi normal) et un **proxy** qui fait passer leur Internet par le Wi-Fi du téléphone principal. Ça fonctionne même quand le point d'accès classique du téléphone refuse de partager le Wi-Fi.

## 1. Obtenir l'APK

### Option A — sans ordinateur, avec GitHub (gratuit)
1. Crée un compte sur https://github.com et un nouveau dépôt (bouton « New »), par exemple `PartageWifi`.
2. Dans le dépôt : **Add file > Upload files**, et envoie tout le contenu du dossier `PartageWifi` (en gardant les dossiers `app` et `.github`). Le plus simple est de le faire depuis un navigateur en « version ordinateur ».
3. Va dans l'onglet **Actions** : la compilation démarre toute seule (3 à 5 minutes).
4. Quand c'est vert ✓, clique dessus, puis en bas sur **PartageWifi-apk** : tu télécharges un .zip qui contient `app-debug.apk`.

### Option B — avec un ordinateur
1. Installe **Android Studio** (gratuit).
2. *File > Open* → choisis le dossier `PartageWifi`.
3. *Build > Build App Bundle(s) / APK(s) > Build APK(s)*.
4. L'APK est dans `app/build/outputs/apk/debug/app-debug.apk`.

## 2. Installer sur le téléphone principal
Copie `app-debug.apk` sur le téléphone, ouvre-le, et autorise « Installer des applis inconnues » quand Android le demande. Si Play Protect affiche un avertissement, choisis « Installer quand même » (l'appli n'est simplement pas publiée sur le Play Store).

## 3. Utiliser

**Téléphone principal**
1. Connecte-toi au Wi-Fi (et à sa page de connexion s'il y en a une). Coupe le point d'accès mobile classique.
2. Ouvre **Partage Wi-Fi** et appuie sur **Démarrer le partage**. Accepte les permissions.
3. Appuie aussi une fois sur « Empêcher Android de couper l'appli » et retire les restrictions de batterie.
4. L'appli affiche le **nom du réseau** et le **mot de passe**.

**Chaque autre téléphone (Android)**
1. Paramètres > Wi-Fi > choisis le réseau affiché (il commence par `DIRECT-`) et entre le mot de passe.
2. Appui long sur ce réseau (ou l'engrenage) > Modifier / Options avancées > **Proxy : Manuel**.
3. Nom d'hôte : `192.168.49.1` — Port : `8282` — Enregistrer.
4. Si « Pas d'accès Internet » s'affiche : choisis **Rester connecté**, et coupe les données mobiles de ce téléphone.

**iPhone** : Réglages > Wi-Fi > (i) > Configurer le proxy > Manuel > Serveur `192.168.49.1`, Port `8282`.

**Ordinateur** : mêmes réglages de proxy dans les paramètres réseau.

## Limites
- Les applis qui ignorent le proxy (certains jeux, certains appels) n'auront pas Internet. Navigateur, YouTube, WhatsApp, Facebook, etc. fonctionnent.
- Fonctionne sur Android 5 et plus. Le nom et le mot de passe personnalisés nécessitent Android 10+ ; sinon Android en choisit automatiquement.
- Si le réseau Wi-Fi source limite le nombre d'appareils ou bloque le partage, la vitesse peut être limitée.
- Le téléphone principal consomme plus de batterie : garde-le branché si possible.
